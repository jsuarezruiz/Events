﻿namespace Xamagram
{
    public static class GlobalSettings
    {
        public const string AzureUrl = "INSERTAR URL AZURE AQUÍ";
        public const string Database = "xamagram.db";
    }
}