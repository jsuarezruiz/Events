﻿using Xamarin.Forms;

namespace HotDogOrNot.ViewModels
{
    public class HotDogViewModel : BindableObject
    {
       
    }
}