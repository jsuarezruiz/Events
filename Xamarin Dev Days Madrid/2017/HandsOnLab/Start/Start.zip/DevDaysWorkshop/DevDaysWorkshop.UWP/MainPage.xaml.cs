﻿namespace DevDaysWorkshop.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();

            LoadApplication(new DevDaysWorkshop.App());
        }
    }
}
