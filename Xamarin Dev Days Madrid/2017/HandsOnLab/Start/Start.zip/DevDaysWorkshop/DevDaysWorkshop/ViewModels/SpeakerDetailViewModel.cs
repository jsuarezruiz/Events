﻿using DevDaysWorkshop.ViewModels.Base;

namespace DevDaysWorkshop.ViewModels
{
    public class SpeakerDetailViewModel : ViewModelBase
    {
        public override void OnAppearing(object navigationContext)
        {
            base.OnAppearing(navigationContext);
        }
    }
}