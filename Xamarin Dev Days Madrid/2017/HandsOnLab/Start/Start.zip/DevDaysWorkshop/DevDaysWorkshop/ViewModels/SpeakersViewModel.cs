﻿using DevDaysWorkshop.ViewModels.Base;

namespace DevDaysWorkshop.ViewModels
{
    public class SpeakersViewModel : ViewModelBase
    {

    }
}