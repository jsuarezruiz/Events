﻿namespace DevDaysWorkshop
{
    public class AppSettings
    {
        public static string AzureUrl = "http://devdaysworkshop.azurewebsites.net/";
    }
}
